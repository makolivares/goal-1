<?php
/**
 * The template used for displaying page content in page.php
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?>

	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<div class="entry-content">
			<div class="slider" style="background: url('<?php the_field('background'); ?>')">
                <div class="slider-content">
                    <div class="slider-wrapper">
                    <h1 class="slider-h1"><?php the_field('slider_title'); ?></h1>
                    <h4 class="slider-h4"><?php the_field('slider_subtitle'); ?></h4>
                        <div class="button-wrapper"><a class="stylebutton2" style="float: left; margin-right: 20px;" href="<?php the_field('1st_button_url'); ?>"><?php the_field('1st_button_text'); ?></a> <a class="stylebutton2" style="float: left;" href="<?php the_field('2nd_button_url'); ?>"><?php the_field('2nd_button_text'); ?></a></div>
                        </div>
                    <div class="clear"></div>
                    </div>
                </div>
            <div class="container">
                <div class="row">
                <div class="col">
                <h1 style="text-align: center;"><?php the_field('2ndconcent_title'); ?></h1>
                <p style="text-align: center;"><?php the_field('2ndcontent_text'); ?></p>
                </div>
                </div>
                <div class="emptyspace"></div>
                <div class="row">
                <div class="col">
                <img class="aligncenter size-full wp-image-39" src="<?php the_field('1st_image'); ?>" alt="" width="130" height="130" />
                <h1><?php the_field('1st_image_title'); ?></h1>
                <p style="text-align: center;"><?php the_field('1st_image_text'); ?></p>
                </div>
                <div class="col">
                <img class="aligncenter size-full wp-image-43" src="<?php the_field('2nd_image'); ?>" alt="" width="130" height="130" />
                <h1><?php the_field('2nd_image_title'); ?></h1>
                <p style="text-align: center;"><?php the_field('2nd_image_text'); ?></p>
                </div>
                <div class="col">
                <img class="aligncenter size-full wp-image-38" src="<?php the_field('3rd_image'); ?>" alt="" width="130" height="130" />
                <h1><?php the_field('3rd_image_title'); ?></h1>
                <p style="text-align: center;"><?php the_field('3rd_image_text'); ?></p>
                </div>
                <div class="clear"></div>
                </div>
            </div>
            <div class="full-width" style="background: #f7f7f7 url('<?php the_field('3rd_background_image'); ?>')no-repeat; background-size: cover; background-position: right;">
                    <div class="container">
                    <div class="row">
                        <div class="col">
                        <h1 style="text-align: left; color: #1d396d;"><?php the_field('3rd_title'); ?></h1>
                        <p style="text-align: left; color: #1d396d;"><?php the_field('3rd_text_content'); ?></p>
                        <a class="stylebutton2" style="float: left; margin-right: 20px;" href="<?php the_field('3rd_1st_button_url'); ?>"><?php the_field('3rd_1st_button_text'); ?></a> <a class="stylebutton2" style="float: left;" href="<?php the_field('3rd_2nd_button_url'); ?>"><?php the_field('3rd_2nd_button_text'); ?></a>
                        </div>
                    <div class="clear"></div>
                    </div>
                    </div>
            </div>
            <div class="container">
                <div class="row">
                <div class="col">
                <h1 style="text-align: center;"><?php the_field('testimonial_title'); ?></h1>
                <p style="text-align: center;"><?php the_field('testimonial_text'); ?></p>
                </div>
                </div>
                <div class="emptyspace"></div>
                <div class="row">
                <div class="col">
                <img class="aligncenter size-full wp-image-39" src="<?php the_field('1st_testimonial_image'); ?>" alt="" width="130" height="130" />
                <h1><?php the_field('1st_testimonial_name'); ?></h1>
                <p style="text-align: center;"><i><?php the_field('1st_testimonial_text'); ?></i></p>
                </div>
                <div class="col">
                <img class="aligncenter size-full wp-image-43" src="<?php the_field('2nd_testimonial_image'); ?>" alt="" width="130" height="130" />
                <h1><?php the_field('2nd_testitmonial_name'); ?></h1>
                <p style="text-align: center;"><i><?php the_field('2nd_testitmonial_text'); ?></i></p>
                </div>
                <div class="col">
                <img class="aligncenter size-full wp-image-38" src="<?php the_field('3rd_testimonial_image'); ?>" alt="" width="130" height="130" />
                <h1><?php the_field('3rd_testimonial_name'); ?></h1>
                <p style="text-align: center;"><i><?php the_field('3rd_testimonial_text'); ?></i></p>
                </div>
                <div class="clear"></div>
                </div>
            </div>
			<?php wp_link_pages( array( 'before' => '<div class="page-links">' . __( 'Pages:', 'twentytwelve' ), 'after' => '</div>' ) ); ?>
		</div><!-- .entry-content -->
		<footer class="entry-meta">
			<?php edit_post_link( __( 'Edit', 'twentytwelve' ), '<span class="edit-link">', '</span>' ); ?>
		</footer><!-- .entry-meta -->
	</article><!-- #post -->

<?php
// Add CSS class by filter 

add_filter('body_class','twentytwelvechild_body_class_adapt',20); function twentytwelvechild_body_class_adapt( $classes ) { // Apply 'full-width' class to form_page.php body 
if ( is_page_template( 'page-templates/my-full-width.php' ) ) $classes[] = 'full-width'; return $classes; }

function my_header_sidebar() {
    register_sidebar(
        array (
            'name' => __( 'Header Sidebar', 'your-theme-domain' ),
            'id' => 'custom-side-bar',
            'description' => __( 'Sidebar For header', 'your-theme-domain' ),
            'before_widget' => '<div class="widget-content">',
            'after_widget' => "</div>",
            'before_title' => '<h3 class="widget-title">',
            'after_title' => '</h3>',
        )
    );
}
add_action( 'widgets_init', 'my_header_sidebar' );

function my_footer_sidebar_left() {
    register_sidebar(
        array (
            'name' => __( 'Footer Sidebar Left', 'your-theme-domain' ),
            'id' => 'custom-side-bar-footer-left',
            'description' => __( 'Sidebar For Footer Left', 'your-theme-domain' ),
            'before_widget' => '<div class="widget-content">',
            'after_widget' => "</div>",
            'before_title' => '<h3 class="widget-title">',
            'after_title' => '</h3>',
        )
    );
}
add_action( 'widgets_init', 'my_footer_sidebar_left' );

function my_footer_sidebar_right() {
    register_sidebar(
        array (
            'name' => __( 'Footer Sidebar Right', 'your-theme-domain' ),
            'id' => 'custom-side-bar-footer-right',
            'description' => __( 'Sidebar For Footer Right', 'your-theme-domain' ),
            'before_widget' => '<div class="widget-content">',
            'after_widget' => "</div>",
            'before_title' => '<h3 class="widget-title">',
            'after_title' => '</h3>',
        )
    );
}
add_action( 'widgets_init', 'my_footer_sidebar_right' );
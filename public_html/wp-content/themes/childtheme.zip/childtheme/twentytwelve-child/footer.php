<?php
/**
 * The template for displaying the footer
 *
 * Contains footer content and the closing of the #main and #page div elements.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?>
	</div><!-- #main .wrapper -->
<div class="full-width footer">
<div class="container">
<div class="row">
<div class="col">
<h1 style="text-align: left;">Lorem ipsum dolor sit amet</h1>
<p style="text-align: left;">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
<a class="stylebutton2" style="float: left; margin-right: 20px;" href="#">Lorem ipsum dolor</a>

</div>
<div class="col">
<h1 style="text-align: left;">Lorem ipsum dolor sit amet</h1>
<p style="text-align: left;">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>

<div class="" id="social">
<div class="col">
    <div class="social-wrapper">
    <img class="aligncenter size-full wp-image-78" src="http://makolivares.online/wp-content/uploads/2018/04/accounting-black-budget-53621_07.jpg" alt="" width="200" height="200"/><img class="aligncenter size-full wp-image-77" src="http://makolivares.online/wp-content/uploads/2018/04/accounting-black-budget-53621_05.jpg" alt="" width="200" height="200" /><img class="aligncenter size-full wp-image-76" src="http://makolivares.online/wp-content/uploads/2018/04/accounting-black-budget-53621_03.jpg" alt="" width="200" height="200" /><img class="aligncenter size-full wp-image-75" src="http://makolivares.online/wp-content/uploads/2018/04/accounting-black-budget-53621_12.jpg" alt="" width="200" height="200" /></div></div>
</div>
</div>
<div class="clear"></div>
</div>
</div>
</div>
	<footer id="colophon" role="contentinfo">
		<div class="site-info">
			<div class="row">
			    <div class="col"><?php dynamic_sidebar( 'custom-side-bar-footer-left' ); ?></div>
			    <div class="col"><?php dynamic_sidebar( 'custom-side-bar-footer-right' ); ?></div>
			</div>
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>